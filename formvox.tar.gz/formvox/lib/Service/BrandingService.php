<?php

declare(strict_types=1);

namespace OCA\FormVox\Service;

use OCP\IConfig;
use OCP\Files\IAppData;
use OCP\Files\NotFoundException;
use OCP\Files\SimpleFS\ISimpleFolder;
use OCA\FormVox\AppInfo\Application;

class BrandingService
{
    private IConfig $config;
    private IAppData $appData;

    private const DEFAULT_BRANDING = [
        'logoEnabled' => false,
        'logoFileId' => null,
        'primaryColor' => '#0082c9',
        'backgroundColor' => '#ffffff',
        'headerText' => '',
        'thankYouTitle' => 'Thank you!',
        'thankYouMessage' => 'Your response has been submitted successfully.',
        'footerText' => '',
    ];

    public function __construct(IConfig $config, IAppData $appData)
    {
        $this->config = $config;
        $this->appData = $appData;
    }

    /**
     * Get all branding settings
     */
    public function getBranding(): array
    {
        $branding = [];
        foreach (self::DEFAULT_BRANDING as $key => $default) {
            $value = $this->config->getAppValue(Application::APP_ID, 'branding_' . $key, '');
            if ($value === '') {
                $branding[$key] = $default;
            } else {
                // Decode JSON for complex values, use raw for simple strings
                $decoded = json_decode($value, true);
                $branding[$key] = $decoded !== null ? $decoded : $value;
            }
        }

        // Add logo URL if logo is enabled
        if ($branding['logoEnabled'] && $branding['logoFileId']) {
            $branding['logoUrl'] = $this->getLogoUrl();
        }

        return $branding;
    }

    /**
     * Save branding settings
     */
    public function saveBranding(array $data): array
    {
        foreach ($data as $key => $value) {
            if (!array_key_exists($key, self::DEFAULT_BRANDING)) {
                continue;
            }
            // Store as JSON for complex types, raw for strings
            if (is_bool($value) || is_array($value) || is_int($value)) {
                $this->config->setAppValue(Application::APP_ID, 'branding_' . $key, json_encode($value));
            } else {
                $this->config->setAppValue(Application::APP_ID, 'branding_' . $key, (string)$value);
            }
        }
        return $this->getBranding();
    }

    /**
     * Save uploaded logo
     */
    public function saveLogo(string $tmpPath, string $mimeType): array
    {
        try {
            $folder = $this->appData->getFolder('branding');
        } catch (NotFoundException $e) {
            $folder = $this->appData->newFolder('branding');
        }

        // Determine extension from mime type
        $extension = 'png';
        if ($mimeType === 'image/jpeg') {
            $extension = 'jpg';
        } elseif ($mimeType === 'image/svg+xml') {
            $extension = 'svg';
        } elseif ($mimeType === 'image/gif') {
            $extension = 'gif';
        }

        $filename = 'logo.' . $extension;

        // Delete old logo if exists
        try {
            $folder->getFile($filename)->delete();
        } catch (NotFoundException $e) {
            // No old file to delete
        }

        // Save new logo
        $content = file_get_contents($tmpPath);
        $file = $folder->newFile($filename);
        $file->putContent($content);

        // Update config
        $this->config->setAppValue(Application::APP_ID, 'branding_logoEnabled', json_encode(true));
        $this->config->setAppValue(Application::APP_ID, 'branding_logoFile', $filename);

        return $this->getBranding();
    }

    /**
     * Delete logo
     */
    public function deleteLogo(): array
    {
        try {
            $folder = $this->appData->getFolder('branding');
            foreach ($folder->getDirectoryListing() as $file) {
                if (strpos($file->getName(), 'logo.') === 0) {
                    $file->delete();
                }
            }
        } catch (NotFoundException $e) {
            // No folder or file to delete
        }

        $this->config->setAppValue(Application::APP_ID, 'branding_logoEnabled', json_encode(false));
        $this->config->deleteAppValue(Application::APP_ID, 'branding_logoFile');

        return $this->getBranding();
    }

    /**
     * Get logo content for serving
     */
    public function getLogo(): ?array
    {
        try {
            $folder = $this->appData->getFolder('branding');
            $filename = $this->config->getAppValue(Application::APP_ID, 'branding_logoFile', 'logo.png');
            $file = $folder->getFile($filename);

            $mimeType = 'image/png';
            if (str_ends_with($filename, '.jpg') || str_ends_with($filename, '.jpeg')) {
                $mimeType = 'image/jpeg';
            } elseif (str_ends_with($filename, '.svg')) {
                $mimeType = 'image/svg+xml';
            } elseif (str_ends_with($filename, '.gif')) {
                $mimeType = 'image/gif';
            }

            return [
                'content' => $file->getContent(),
                'mimeType' => $mimeType,
            ];
        } catch (NotFoundException $e) {
            return null;
        }
    }

    /**
     * Get logo URL for frontend
     */
    private function getLogoUrl(): string
    {
        return \OC::$server->getURLGenerator()->linkToRoute('formvox.branding.logo');
    }
}
