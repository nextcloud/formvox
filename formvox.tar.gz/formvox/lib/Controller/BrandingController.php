<?php

declare(strict_types=1);

namespace OCA\FormVox\Controller;

use OCP\AppFramework\Controller;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;
use OCP\AppFramework\Http\Attribute\PublicPage;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\Http\DataDisplayResponse;
use OCP\IRequest;
use OCA\FormVox\AppInfo\Application;
use OCA\FormVox\Service\BrandingService;

class BrandingController extends Controller
{
    private BrandingService $brandingService;

    public function __construct(
        IRequest $request,
        BrandingService $brandingService
    ) {
        parent::__construct(Application::APP_ID, $request);
        $this->brandingService = $brandingService;
    }

    /**
     * Get branding settings (admin only)
     */
    public function get(): DataResponse
    {
        return new DataResponse($this->brandingService->getBranding());
    }

    /**
     * Save branding settings (admin only)
     */
    public function save(
        ?bool $logoEnabled = null,
        ?string $primaryColor = null,
        ?string $backgroundColor = null,
        ?string $headerText = null,
        ?string $thankYouTitle = null,
        ?string $thankYouMessage = null,
        ?string $footerText = null
    ): DataResponse {
        $data = [];
        if ($logoEnabled !== null) $data['logoEnabled'] = $logoEnabled;
        if ($primaryColor !== null) $data['primaryColor'] = $primaryColor;
        if ($backgroundColor !== null) $data['backgroundColor'] = $backgroundColor;
        if ($headerText !== null) $data['headerText'] = $headerText;
        if ($thankYouTitle !== null) $data['thankYouTitle'] = $thankYouTitle;
        if ($thankYouMessage !== null) $data['thankYouMessage'] = $thankYouMessage;
        if ($footerText !== null) $data['footerText'] = $footerText;

        $branding = $this->brandingService->saveBranding($data);
        return new DataResponse($branding);
    }

    /**
     * Upload logo (admin only)
     */
    public function uploadLogo(): DataResponse
    {
        $file = $this->request->getUploadedFile('logo');
        if ($file === null || $file['error'] !== UPLOAD_ERR_OK) {
            return new DataResponse(
                ['error' => 'No file uploaded'],
                Http::STATUS_BAD_REQUEST
            );
        }

        $allowedTypes = ['image/png', 'image/jpeg', 'image/svg+xml', 'image/gif'];
        if (!in_array($file['type'], $allowedTypes)) {
            return new DataResponse(
                ['error' => 'Invalid file type. Allowed: PNG, JPEG, SVG, GIF'],
                Http::STATUS_BAD_REQUEST
            );
        }

        $maxSize = 2 * 1024 * 1024; // 2MB
        if ($file['size'] > $maxSize) {
            return new DataResponse(
                ['error' => 'File too large. Maximum size: 2MB'],
                Http::STATUS_BAD_REQUEST
            );
        }

        $branding = $this->brandingService->saveLogo($file['tmp_name'], $file['type']);
        return new DataResponse($branding);
    }

    /**
     * Delete logo (admin only)
     */
    public function deleteLogo(): DataResponse
    {
        $branding = $this->brandingService->deleteLogo();
        return new DataResponse($branding);
    }

    /**
     * Serve logo (public access)
     */
    #[PublicPage]
    #[NoCSRFRequired]
    public function logo(): DataDisplayResponse
    {
        $logo = $this->brandingService->getLogo();
        if ($logo === null) {
            return new DataDisplayResponse('', Http::STATUS_NOT_FOUND);
        }

        $response = new DataDisplayResponse($logo['content']);
        $response->addHeader('Content-Type', $logo['mimeType']);
        $response->cacheFor(3600); // Cache for 1 hour
        return $response;
    }
}
