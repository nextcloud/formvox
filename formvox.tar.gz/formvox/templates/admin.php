<?php
/**
 * Admin settings template
 */
?>
<div id="formvox-admin"></div>
