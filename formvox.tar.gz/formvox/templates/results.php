<?php
/**
 * FormVox - Results template
 * Initial state is provided by PageController via IInitialState
 */

declare(strict_types=1);
?>

<div id="formvox-results"></div>
