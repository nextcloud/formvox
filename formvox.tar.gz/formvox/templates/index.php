<?php
/**
 * FormVox - Main application template
 * Scripts are loaded by PageController
 */

declare(strict_types=1);
?>

<div id="formvox-app"></div>
