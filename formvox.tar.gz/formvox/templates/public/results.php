<?php
/**
 * FormVox - Public results template
 * Initial state is provided by PublicController via IInitialState
 */

declare(strict_types=1);
?>

<div id="formvox-results"></div>
