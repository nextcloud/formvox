<?php
/**
 * FormVox - Form editor template
 * Initial state is provided by PageController via IInitialState
 */

declare(strict_types=1);
?>

<div id="formvox-editor"></div>
